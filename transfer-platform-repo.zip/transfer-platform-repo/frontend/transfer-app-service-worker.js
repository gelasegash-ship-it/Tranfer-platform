/**
 * TRANSFER PLATFORM - SERVICE WORKER
 * Offline-first PWA with intelligent caching
 * 
 * Strategy:
 * - Static assets: Cache-first
 * - API calls: Network-first with fallback
 * - Transfers: Queue for later sync
 */

const CACHE_NAME = 'transfer-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/favicon.ico',
  '/styles/main.css',
  '/fonts/*'
];

// ============================================================================
// INSTALLATION
// ============================================================================

self.addEventListener('install', (event) => {
  console.log('[ServiceWorker] Installing...');
  
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[ServiceWorker] Caching static assets');
      return cache.addAll(STATIC_ASSETS);
    })
  );
  
  // Force the waiting service worker to become the active service worker
  self.skipWaiting();
});

// ============================================================================
// ACTIVATION
// ============================================================================

self.addEventListener('activate', (event) => {
  console.log('[ServiceWorker] Activating...');
  
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((cacheName) => cacheName !== CACHE_NAME)
          .map((cacheName) => {
            console.log(`[ServiceWorker] Deleting old cache: ${cacheName}`);
            return caches.delete(cacheName);
          })
      );
    })
  );
  
  self.clients.claim();
});

// ============================================================================
// FETCH STRATEGIES
// ============================================================================

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests
  if (request.method !== 'GET') {
    // Queue POST requests (transfers) for sync
    if (request.url.includes('/api/transfers')) {
      event.respondWith(queueTransferSync(request));
    }
    return;
  }

  // Static assets: Cache-first
  if (isStaticAsset(url.pathname)) {
    event.respondWith(cacheFirst(request));
    return;
  }

  // API calls: Network-first
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(networkFirst(request));
    return;
  }

  // Default: Network-first
  event.respondWith(networkFirst(request));
});

// ============================================================================
// CACHING STRATEGIES
// ============================================================================

/**
 * Cache-first strategy
 * Try cache first, fall back to network
 */
async function cacheFirst(request) {
  const cache = await caches.open(CACHE_NAME);
  const cached = await cache.match(request);
  
  if (cached) {
    console.log(`[Cache] Hit: ${request.url}`);
    return cached;
  }

  try {
    const response = await fetch(request);
    
    if (response.ok) {
      cache.put(request, response.clone());
    }
    
    return response;
  } catch (error) {
    console.error(`[Fetch] Error: ${request.url}`, error);
    
    // Return offline page or cached response
    return new Response(
      JSON.stringify({
        error: 'offline',
        message: 'You are offline. Please check your connection.'
      }),
      { status: 503, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

/**
 * Network-first strategy
 * Try network first, fall back to cache
 */
async function networkFirst(request) {
  try {
    const response = await fetch(request, {
      signal: AbortSignal.timeout(5000) // 5s timeout
    });

    if (response.ok) {
      const cache = await caches.open(CACHE_NAME);
      cache.put(request, response.clone());
    }

    return response;
  } catch (error) {
    console.warn(`[Network] Failed: ${request.url}`, error);

    // Fallback to cache
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);

    if (cached) {
      console.log(`[Cache] Fallback: ${request.url}`);
      return cached;
    }

    // Return offline error
    return new Response(
      JSON.stringify({
        error: 'offline',
        message: 'Network request failed and no cached version available.'
      }),
      {
        status: 503,
        headers: { 'Content-Type': 'application/json' }
      }
    );
  }
}

/**
 * Queue transfer for sync when offline
 */
async function queueTransferSync(request) {
  const clonedRequest = request.clone();
  const body = await clonedRequest.json();

  try {
    // Try to send immediately
    const response = await fetch(request);
    return response;
  } catch (error) {
    console.log('[Sync] Transfer queued for later', body);

    // Queue in IndexedDB for sync
    await queueInDB({
      type: 'transfer',
      payload: body,
      timestamp: Date.now(),
      id: body.id || generateId()
    });

    // Return success to UI (will sync when online)
    return new Response(
      JSON.stringify({
        id: body.id || generateId(),
        status: 'queued_offline',
        message: 'Transfer queued. Will sync when online.'
      }),
      {
        status: 202,
        headers: { 'Content-Type': 'application/json' }
      }
    );
  }
}

/**
 * Queue data in IndexedDB
 */
function queueInDB(data) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('transfer-db', 1);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains('sync-queue')) {
        db.createObjectStore('sync-queue', { keyPath: 'id' });
      }
    };

    request.onsuccess = () => {
      const db = request.result;
      const tx = db.transaction('sync-queue', 'readwrite');
      const store = tx.objectStore('sync-queue');
      store.add(data);

      tx.oncomplete = () => {
        resolve();
        // Trigger sync event
        self.registration.sync.register('sync-transfers');
      };

      tx.onerror = () => reject(tx.error);
    };

    request.onerror = () => reject(request.error);
  });
}

// ============================================================================
// BACKGROUND SYNC
// ============================================================================

/**
 * Sync queued transfers when connection is restored
 */
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-transfers') {
    event.waitUntil(syncQueuedTransfers());
  }
});

async function syncQueuedTransfers() {
  return new Promise((resolve) => {
    const request = indexedDB.open('transfer-db');

    request.onsuccess = () => {
      const db = request.result;
      const tx = db.transaction('sync-queue', 'readonly');
      const store = tx.objectStore('sync-queue');
      const allRecords = store.getAll();

      allRecords.onsuccess = async () => {
        const transfers = allRecords.result;
        console.log(`[Sync] Found ${transfers.length} queued transfers`);

        for (const transfer of transfers) {
          try {
            const response = await fetch('/api/transfers', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(transfer.payload)
            });

            if (response.ok) {
              // Remove from queue
              const deleteTx = db.transaction('sync-queue', 'readwrite');
              deleteTx.objectStore('sync-queue').delete(transfer.id);
              
              // Notify all clients
              self.clients.matchAll().then((clients) => {
                clients.forEach((client) => {
                  client.postMessage({
                    type: 'sync:success',
                    transfer: transfer.payload
                  });
                });
              });
            }
          } catch (error) {
            console.error('[Sync] Failed to sync transfer', error);
          }
        }

        resolve();
      };
    };
  });
}

// ============================================================================
// PUSH NOTIFICATIONS
// ============================================================================

/**
 * Handle push notifications for transaction updates
 */
self.addEventListener('push', (event) => {
  if (!event.data) return;

  const data = event.data.json();
  const options = {
    badge: '/badge-72x72.png',
    icon: '/icon-192x192.png',
    body: data.body || 'Transaction update',
    tag: data.transactionId,
    data: {
      transactionId: data.transactionId,
      status: data.status
    }
  };

  event.waitUntil(
    self.registration.showNotification(data.title || '💸 TRANSFER', options)
  );
});

/**
 * Handle notification clicks
 */
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  event.waitUntil(
    clients.matchAll({ type: 'window' }).then((clientList) => {
      // If a window with the target URL already exists, focus it.
      for (const client of clientList) {
        if (client.url === '/' && 'focus' in client) {
          return client.focus();
        }
      }
      // If not, open a new window
      if (clients.openWindow) {
        return clients.openWindow('/');
      }
    })
  );
});

// ============================================================================
// PERIODIC BACKGROUND SYNC
// ============================================================================

/**
 * Periodic sync for refresh (if supported)
 */
if ('periodicSync' in self.registration) {
  self.addEventListener('periodicsync', (event) => {
    if (event.tag === 'refresh-data') {
      event.waitUntil(refreshBalanceAndTransactions());
    }
  });
}

async function refreshBalanceAndTransactions() {
  try {
    const response = await fetch('/api/user/profile');
    const data = await response.json();

    // Notify all clients
    self.clients.matchAll().then((clients) => {
      clients.forEach((client) => {
        client.postMessage({
          type: 'data:refreshed',
          data
        });
      });
    });
  } catch (error) {
    console.error('[Sync] Failed to refresh data', error);
  }
}

// ============================================================================
// UTILITIES
// ============================================================================

function isStaticAsset(pathname) {
  const staticExtensions = ['.js', '.css', '.png', '.jpg', '.svg', '.woff', '.woff2'];
  return staticExtensions.some((ext) => pathname.endsWith(ext)) || pathname === '/';
}

function generateId() {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

// ============================================================================
// LOGGING
// ============================================================================

console.log('[ServiceWorker] Loaded and ready');
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
