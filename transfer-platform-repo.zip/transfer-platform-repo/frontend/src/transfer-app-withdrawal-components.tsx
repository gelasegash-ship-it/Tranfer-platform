/**
 * TRANSFER PLATFORM - WITHDRAWAL UI COMPONENTS
 * Complete withdrawal interface with all modals and screens
 */

import React, { useState, useEffect } from 'react';
import {
  withdrawalService,
  mockWithdrawalMethods,
  mockCalculateWithdrawal,
  mockValidateRecipient,
  mockCreateWithdrawal,
  mockConfirmWithdrawal,
  type Withdrawal,
  type WithdrawalMethod,
  type WithdrawalLimit
} from './transfer-app-withdrawal-system';

// ============================================================================
// WITHDRAWAL METHOD SELECTOR
// ============================================================================

export function WithdrawalMethodSelector({
  isOpen,
  onClose,
  onSelect,
  isLoading
}: {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (method: WithdrawalMethod) => void;
  isLoading?: boolean;
}) {
  const [methods, setMethods] = useState<WithdrawalMethod[]>(mockWithdrawalMethods);
  const [selectedType, setSelectedType] = useState<string>('all');

  const filtered =
    selectedType === 'all'
      ? methods
      : methods.filter((m) => m.type === selectedType);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-end z-50">
      <div className="bg-white w-full rounded-t-2xl p-6 max-h-[90vh] overflow-auto">
        <div className="mb-6">
          <h2 className="text-2xl font-bold">Méthode de retrait</h2>
          <p className="text-gray-600">Sélectionnez comment recevoir votre argent</p>
        </div>

        {/* Filter tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {['all', 'mobile_money', 'bank', 'crypto', 'agent'].map((type) => (
            <button
              key={type}
              onClick={() => setSelectedType(type)}
              className={`px-4 py-2 rounded-full whitespace-nowrap transition ${
                selectedType === type
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {type === 'all' && 'Tous'}
              {type === 'mobile_money' && 'Mobile Money'}
              {type === 'bank' && 'Banque'}
              {type === 'crypto' && 'Crypto'}
              {type === 'agent' && 'Agent'}
            </button>
          ))}
        </div>

        {/* Methods grid */}
        <div className="space-y-3">
          {filtered.map((method) => (
            <button
              key={method.id}
              onClick={() => {
                onSelect(method);
                onClose();
              }}
              disabled={!method.available || isLoading}
              className={`w-full p-4 rounded-lg border-2 transition text-left ${
                !method.available
                  ? 'opacity-50 cursor-not-allowed border-gray-200 bg-gray-50'
                  : 'border-gray-200 hover:border-blue-500 hover:bg-blue-50 active:bg-blue-100'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <div className="text-3xl">{method.icon}</div>
                  <div className="flex-1">
                    <div className="font-bold text-lg">{method.name}</div>
                    <div className="text-xs text-gray-600">{method.provider}</div>
                    <div className="flex gap-4 mt-2 text-xs text-gray-600">
                      <span>⏱️ {method.processingTime}</span>
                      <span>💰 {method.fee}% frais</span>
                    </div>
                  </div>
                </div>
                {!method.available && (
                  <div className="text-xs font-bold text-red-500">Indisponible</div>
                )}
              </div>
              <div className="mt-3 pt-3 border-t text-xs text-gray-600">
                Min: {method.minAmount.toLocaleString()} {method.currency} | Max:{' '}
                {method.maxAmount.toLocaleString()} {method.currency}
              </div>
            </button>
          ))}
        </div>

        <button
          onClick={onClose}
          className="w-full mt-6 py-3 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold rounded-lg transition"
        >
          Annuler
        </button>
      </div>
    </div>
  );
}

// ============================================================================
// WITHDRAWAL AMOUNT & RECIPIENT FORM
// ============================================================================

export function WithdrawalForm({
  isOpen,
  onClose,
  onSubmit,
  method,
  balance,
  isLoading
}: {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => Promise<void>;
  method: WithdrawalMethod | null;
  balance: number;
  isLoading?: boolean;
}) {
  const [step, setStep] = useState<'amount' | 'recipient' | 'confirm'>('amount');
  const [amount, setAmount] = useState('');
  const [recipient, setRecipient] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [calculation, setCalculation] = useState<any>(null);
  const [recipientValid, setRecipientValid] = useState(false);
  const [error, setError] = useState<string>('');

  if (!isOpen || !method) return null;

  const handleCalculate = async () => {
    try {
      setError('');
      const result = await mockCalculateWithdrawal(method.id, parseInt(amount));
      setCalculation(result);
      setStep('recipient');
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleValidateRecipient = async () => {
    try {
      setError('');
      const result = await mockValidateRecipient(method.id, recipient);
      if (result.valid) {
        setRecipientName(result.name || '');
        setRecipientValid(true);
        setStep('confirm');
      } else {
        setError(result.error || 'Invalid recipient');
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleConfirm = async () => {
    try {
      setError('');
      await onSubmit({
        methodId: method.id,
        amount: parseInt(amount),
        currency: method.currency,
        recipient: {
          type: method.type === 'crypto' ? 'wallet' : method.type === 'bank' ? 'account' : 'phone',
          identifier: recipient,
          name: recipientName
        }
      });
    } catch (err: any) {
      setError(err.message);
    }
  };

  const availableToWithdraw = Math.min(balance, method.maxAmount);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-end z-50">
      <div className="bg-white w-full rounded-t-2xl p-6 max-h-[90vh] overflow-auto">
        <div className="mb-6">
          <button
            onClick={() => {
              if (step === 'amount') {
                onClose();
              } else if (step === 'recipient') {
                setStep('amount');
              } else {
                setStep('recipient');
              }
            }}
            className="text-blue-500 font-medium mb-2"
          >
            ← Retour
          </button>
          <h2 className="text-2xl font-bold">
            {step === 'amount' && 'Montant du retrait'}
            {step === 'recipient' && 'Destinataire'}
            {step === 'confirm' && 'Confirmer le retrait'}
          </h2>
        </div>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}

        {step === 'amount' && (
          <div className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="text-sm text-gray-600">Solde disponible</div>
              <div className="text-2xl font-bold text-blue-600">
                {new Intl.NumberFormat('fr-FR').format(balance)} {method.currency}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Montant à retirer</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  placeholder="0"
                  value={amount}
                  onChange={(e) => {
                    setAmount(e.target.value);
                    setCalculation(null);
                  }}
                  min={method.minAmount}
                  max={availableToWithdraw}
                  className="flex-1 border-2 border-gray-300 rounded px-4 py-3 text-lg focus:border-blue-500 outline-none"
                />
                <button
                  onClick={() => setAmount(String(availableToWithdraw))}
                  className="px-4 py-3 bg-gray-200 hover:bg-gray-300 font-bold rounded transition"
                >
                  Max
                </button>
              </div>
              <div className="text-xs text-gray-600 mt-2">
                Min: {method.minAmount.toLocaleString()} | Max:{' '}
                {availableToWithdraw.toLocaleString()}
              </div>
            </div>

            {amount && calculation && (
              <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">Montant</span>
                  <span className="font-bold">
                    {new Intl.NumberFormat('fr-FR').format(calculation.amount)}{' '}
                    {method.currency}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Frais ({method.fee}%)</span>
                  <span className="font-bold">
                    -{new Intl.NumberFormat('fr-FR').format(calculation.fee)}{' '}
                    {method.currency}
                  </span>
                </div>
                {calculation.exchangeRate && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Taux de change</span>
                    <span className="font-bold">1 USD = {calculation.exchangeRate} XAF</span>
                  </div>
                )}
                <div className="flex justify-between border-t pt-2 font-bold text-lg">
                  <span>Vous recevrez</span>
                  <span className="text-green-600">
                    {new Intl.NumberFormat('fr-FR').format(calculation.netAmount)}{' '}
                    {calculation.finalCurrency || method.currency}
                  </span>
                </div>
              </div>
            )}

            <button
              onClick={handleCalculate}
              disabled={!amount || isLoading}
              className="w-full bg-blue-500 hover:bg-blue-600 disabled:bg-gray-300 text-white font-bold py-3 rounded-lg transition"
            >
              {isLoading ? 'Chargement...' : 'Continuer'}
            </button>
          </div>
        )}

        {step === 'recipient' && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                {method.type === 'crypto' && 'Adresse portefeuille'}
                {method.type === 'bank' && 'Numéro de compte'}
                {method.type === 'agent' && 'Numéro de téléphone'}
                {method.type === 'mobile_money' && 'Numéro de téléphone'}
              </label>
              <input
                type={method.type === 'crypto' ? 'text' : 'tel'}
                placeholder={
                  method.type === 'crypto'
                    ? '0x...'
                    : method.type === 'bank'
                      ? '1234567890'
                      : '+243 77 000 0000'
                }
                value={recipient}
                onChange={(e) => {
                  setRecipient(e.target.value);
                  setRecipientValid(false);
                }}
                className="w-full border-2 border-gray-300 rounded px-4 py-3 focus:border-blue-500 outline-none"
              />
            </div>

            <button
              onClick={handleValidateRecipient}
              disabled={!recipient || isLoading}
              className="w-full bg-blue-500 hover:bg-blue-600 disabled:bg-gray-300 text-white font-bold py-3 rounded-lg transition"
            >
              {isLoading ? 'Validation...' : 'Valider'}
            </button>
          </div>
        )}

        {step === 'confirm' && calculation && (
          <div className="space-y-4">
            <div className="bg-gradient-to-r from-green-100 to-blue-100 p-6 rounded-lg">
              <div className="text-sm text-gray-600 mb-2">Résumé du retrait</div>

              <div className="space-y-3 mb-4">
                <div>
                  <div className="text-sm text-gray-600">Montant</div>
                  <div className="text-2xl font-bold">
                    {new Intl.NumberFormat('fr-FR').format(calculation.amount)}{' '}
                    {method.currency}
                  </div>
                </div>

                <div className="bg-white rounded p-3">
                  <div className="text-sm text-gray-600">Vers</div>
                  <div className="font-bold text-lg">{method.name}</div>
                  <div className="text-sm text-gray-600">
                    {recipientName ? (
                      <>
                        <div>{recipientName}</div>
                        <div className="text-xs">{recipient}</div>
                      </>
                    ) : (
                      recipient
                    )}
                  </div>
                </div>

                <div>
                  <div className="text-sm text-gray-600">Vous recevrez</div>
                  <div className="text-xl font-bold text-green-600">
                    {new Intl.NumberFormat('fr-FR').format(calculation.netAmount)}{' '}
                    {calculation.finalCurrency || method.currency}
                  </div>
                  <div className="text-xs text-gray-600 mt-1">
                    Frais: -{new Intl.NumberFormat('fr-FR').format(calculation.fee)}{' '}
                    {method.currency}
                  </div>
                </div>

                <div>
                  <div className="text-sm text-gray-600">Temps de traitement</div>
                  <div className="font-bold">{method.processingTime}</div>
                </div>
              </div>

              <div className="bg-white rounded p-3 text-xs text-gray-600">
                ⚠️ Ce retrait ne peut pas être annulé une fois confirmé.
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleConfirm}
                disabled={isLoading}
                className="flex-1 bg-green-500 hover:bg-green-600 disabled:bg-gray-300 text-white font-bold py-3 rounded-lg transition"
              >
                {isLoading ? 'Traitement...' : '✓ Confirmer'}
              </button>
              <button
                onClick={() => setStep('recipient')}
                className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 rounded-lg transition"
              >
                Modifier
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// OTP CONFIRMATION
// ============================================================================

export function WithdrawalOTPConfirm({
  isOpen,
  onClose,
  onConfirm,
  isLoading,
  withdrawalId
}: {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (otp: string) => Promise<void>;
  isLoading?: boolean;
  withdrawalId: string;
}) {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [error, setError] = useState('');

  const handleChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);

    // Auto-focus next
    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      if (nextInput) (nextInput as HTMLInputElement).focus();
    }
  };

  const handleBackspace = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`);
      if (prevInput) (prevInput as HTMLInputElement).focus();
    }
  };

  const handleConfirm = async () => {
    try {
      setError('');
      const otpCode = otp.join('');
      if (otpCode.length !== 6) {
        setError('Veuillez entrer 6 chiffres');
        return;
      }
      await onConfirm(otpCode);
    } catch (err: any) {
      setError(err.message);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-8 max-w-md w-full mx-4">
        <h2 className="text-2xl font-bold mb-2">Vérification OTP</h2>
        <p className="text-gray-600 mb-6">
          Entrez le code à 6 chiffres envoyé à votre téléphone
        </p>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}

        <div className="flex justify-center gap-2 mb-6">
          {otp.map((digit, index) => (
            <input
              key={index}
              id={`otp-${index}`}
              type="text"
              value={digit}
              onChange={(e) => handleChange(index, e.target.value)}
              onKeyDown={(e) => handleBackspace(index, e)}
              maxLength={1}
              className="w-12 h-12 text-center text-2xl font-bold border-2 border-gray-300 rounded-lg focus:border-blue-500 outline-none"
            />
          ))}
        </div>

        <div className="flex gap-2">
          <button
            onClick={handleConfirm}
            disabled={isLoading || otp.join('').length !== 6}
            className="flex-1 bg-blue-500 hover:bg-blue-600 disabled:bg-gray-300 text-white font-bold py-3 rounded-lg transition"
          >
            {isLoading ? 'Vérification...' : 'Confirmer'}
          </button>
          <button
            onClick={onClose}
            className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 rounded-lg transition"
          >
            Annuler
          </button>
        </div>

        <div className="text-center text-sm text-gray-600 mt-4">
          Pas reçu de code? <button className="text-blue-500 hover:underline">Renvoyer</button>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// WITHDRAWAL HISTORY
// ============================================================================

export function WithdrawalHistory({
  withdrawals,
  isLoading,
  onRetry,
  onCancel
}: {
  withdrawals: Withdrawal[];
  isLoading?: boolean;
  onRetry?: (withdrawal: Withdrawal) => void;
  onCancel?: (withdrawal: Withdrawal) => void;
}) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      case 'cancelled':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      pending: '⏳ En attente',
      processing: '⚙️ Traitement',
      completed: '✅ Complété',
      failed: '❌ Échoué',
      cancelled: '🚫 Annulé',
      approved: '✓ Approuvé'
    };
    return labels[status] || status;
  };

  return (
    <div>
      <h3 className="text-lg font-bold mb-4">Historique des retraits</h3>

      {isLoading && (
        <div className="text-center py-8 text-gray-600">Chargement...</div>
      )}

      {!isLoading && withdrawals.length === 0 && (
        <div className="text-center py-8 text-gray-600">Aucun retrait encore</div>
      )}

      <div className="space-y-3">
        {withdrawals.map((withdrawal) => (
          <div
            key={withdrawal.id}
            className="bg-white border rounded-lg p-4 hover:shadow-md transition"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-start gap-3 flex-1">
                <div className="text-2xl">{withdrawal.method.icon}</div>
                <div className="flex-1">
                  <div className="font-bold">{withdrawal.method.name}</div>
                  <div className="text-sm text-gray-600">
                    {withdrawal.recipient.name || withdrawal.recipient.identifier}
                  </div>
                </div>
              </div>
              <div className={`px-3 py-1 rounded-full text-xs font-bold ${getStatusColor(withdrawal.status)}`}>
                {getStatusLabel(withdrawal.status)}
              </div>
            </div>

            <div className="flex justify-between items-end">
              <div>
                <div className="text-xs text-gray-600">Montant demandé</div>
                <div className="font-bold text-lg">
                  -{new Intl.NumberFormat('fr-FR').format(withdrawal.amount)}{' '}
                  {withdrawal.currency}
                </div>
                <div className="text-xs text-gray-600 mt-1">
                  Reçu: {new Intl.NumberFormat('fr-FR').format(withdrawal.netAmount)}{' '}
                  {withdrawal.currency}
                </div>
              </div>

              <div className="text-right">
                <div className="text-xs text-gray-600">
                  {new Date(withdrawal.createdAt).toLocaleDateString('fr-FR')}
                </div>

                {withdrawal.transactionHash && (
                  <a
                    href={`https://polygonscan.com/tx/${withdrawal.transactionHash}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-blue-500 hover:underline"
                  >
                    Preuve ↗
                  </a>
                )}

                {withdrawal.status === 'failed' && onRetry && (
                  <button
                    onClick={() => onRetry(withdrawal)}
                    className="text-xs text-blue-500 hover:underline block"
                  >
                    Réessayer
                  </button>
                )}

                {withdrawal.status === 'pending' && onCancel && (
                  <button
                    onClick={() => onCancel(withdrawal)}
                    className="text-xs text-red-500 hover:underline block"
                  >
                    Annuler
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================================
// WITHDRAWAL QUICK BUTTON (For Dashboard)
// ============================================================================

export function WithdrawalButton({
  onClick,
  disabled,
  balance
}: {
  onClick: () => void;
  disabled?: boolean;
  balance: number;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled || balance === 0}
      className={`bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 disabled:from-gray-300 disabled:to-gray-400 text-white font-bold py-4 rounded-lg transition flex items-center justify-center gap-2 w-full ${
        disabled ? 'cursor-not-allowed' : ''
      }`}
    >
      <span>💸</span> Retirer
    </button>
  );
}
