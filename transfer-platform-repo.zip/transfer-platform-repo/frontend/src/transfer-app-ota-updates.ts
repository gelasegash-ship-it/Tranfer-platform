/**
 * TRANSFER PLATFORM - OTA UPDATE SYSTEM
 * Over-The-Air automatic updates with zero downtime
 * 
 * Features:
 * - Background updates
 * - Version checking
 * - Delta updates (only changed files)
 * - Rollback capability
 * - Progressive deployment
 */

// ============================================================================
// UPDATE MANAGER SERVICE
// ============================================================================

interface UpdateManifest {
  version: string;
  buildNumber: number;
  releaseDate: string;
  features: string[];
  bugFixes: string[];
  securityFixes?: string[];
  downloadUrl: string;
  checksumSHA256: string;
  size: number; // in bytes
  minVersion: string;
  compatiblePlatforms: string[];
  critical: boolean;
  rolloutPercentage: number;
  changelog: string;
}

interface UpdateProgress {
  status: 'idle' | 'checking' | 'downloading' | 'extracting' | 'installing' | 'completed' | 'failed';
  progress: number; // 0-100
  currentSize: number;
  totalSize: number;
  errorMessage?: string;
  eta?: number; // seconds
}

class OTAUpdateManager {
  private updateServer = process.env.REACT_APP_UPDATE_SERVER || 'https://updates.transfer.app';
  private currentVersion = '1.0.0';
  private updateCheckInterval = 3600000; // 1 hour
  private updateProgress: UpdateProgress = {
    status: 'idle',
    progress: 0,
    currentSize: 0,
    totalSize: 0
  };
  private listeners: Set<(progress: UpdateProgress) => void> = new Set();

  /**
   * Initialize update manager
   */
  async init() {
    console.log('[OTA] Initializing update manager');
    this.checkForUpdates();
    
    // Check periodically
    setInterval(() => this.checkForUpdates(), this.updateCheckInterval);

    // Check on app resume
    if ('addEventListener' in document) {
      document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
          this.checkForUpdates();
        }
      });
    }
  }

  /**
   * Check for available updates
   */
  async checkForUpdates(): Promise<UpdateManifest | null> {
    console.log('[OTA] Checking for updates...');
    this.updateProgress.status = 'checking';
    this.notify();

    try {
      const response = await fetch(`${this.updateServer}/manifest`, {
        headers: {
          'X-Current-Version': this.currentVersion,
          'X-Platform': this.getPlatform(),
          'X-Device-Id': this.getDeviceId()
        }
      });

      if (!response.ok) {
        throw new Error('Failed to fetch update manifest');
      }

      const manifest: UpdateManifest = await response.json();

      // Check if user is in rollout
      if (!this.isUserInRollout(manifest.rolloutPercentage)) {
        console.log('[OTA] User not in rollout percentage');
        this.updateProgress.status = 'idle';
        this.notify();
        return null;
      }

      // Check version compatibility
      if (this.compareVersions(manifest.minVersion, this.currentVersion) > 0) {
        console.log('[OTA] Current version too old for update');
        return null;
      }

      console.log(`[OTA] Update available: ${manifest.version}`);
      
      // Auto-download critical updates
      if (manifest.critical) {
        console.log('[OTA] Critical update detected, downloading...');
        await this.downloadUpdate(manifest);
      } else {
        // Schedule download for later (e.g., when on WiFi)
        this.scheduleDownload(manifest);
      }

      return manifest;
    } catch (error) {
      console.error('[OTA] Error checking for updates:', error);
      this.updateProgress.status = 'failed';
      this.updateProgress.errorMessage = String(error);
      this.notify();
      return null;
    }
  }

  /**
   * Download update
   */
  private async downloadUpdate(manifest: UpdateManifest): Promise<void> {
    console.log(`[OTA] Downloading update ${manifest.version}`);
    this.updateProgress.status = 'downloading';
    this.updateProgress.totalSize = manifest.size;
    this.notify();

    try {
      const response = await fetch(manifest.downloadUrl);

      if (!response.ok) {
        throw new Error('Download failed');
      }

      const contentLength = response.headers.get('content-length');
      if (!contentLength) {
        throw new Error('No content-length header');
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('No response body');
      }

      let receivedLength = 0;
      const chunks: Uint8Array[] = [];

      while (true) {
        const { done, value } = await reader.read();

        if (done) break;

        chunks.push(value);
        receivedLength += value.length;

        this.updateProgress.currentSize = receivedLength;
        this.updateProgress.progress = Math.round((receivedLength / parseInt(contentLength)) * 100);
        this.notify();
      }

      const blob = new Blob(chunks);

      // Verify checksum
      const calculatedChecksum = await this.calculateSHA256(blob);
      if (calculatedChecksum !== manifest.checksumSHA256) {
        throw new Error('Checksum mismatch - download corrupted');
      }

      // Store for installation
      await this.storeUpdate(manifest, blob);
      
      this.updateProgress.status = 'extracting';
      this.notify();

      // Extract and prepare
      await this.prepareUpdate(manifest, blob);

      console.log('[OTA] Update downloaded and verified');
    } catch (error) {
      console.error('[OTA] Download error:', error);
      this.updateProgress.status = 'failed';
      this.updateProgress.errorMessage = String(error);
      this.notify();
      throw error;
    }
  }

  /**
   * Prepare update for installation
   */
  private async prepareUpdate(manifest: UpdateManifest, blob: Blob): Promise<void> {
    try {
      // Extract ZIP file
      const { unzipSync } = await import('fflate');
      const buffer = await blob.arrayBuffer();
      const files = unzipSync(new Uint8Array(buffer));

      // Store in IndexedDB
      const db = await this.openUpdateDB();
      const tx = db.transaction('updates', 'readwrite');
      const store = tx.objectStore('updates');

      // Save manifest
      await new Promise((resolve, reject) => {
        const req = store.put({
          key: `manifest-${manifest.version}`,
          value: manifest,
          timestamp: Date.now()
        });
        req.onsuccess = resolve;
        req.onerror = () => reject(req.error);
      });

      // Save files
      for (const [filename, data] of Object.entries(files)) {
        await new Promise((resolve, reject) => {
          const req = store.put({
            key: `file-${manifest.version}-${filename}`,
            value: new Blob([data]),
            filename,
            timestamp: Date.now()
          });
          req.onsuccess = resolve;
          req.onerror = () => reject(req.error);
        });
      }

      console.log('[OTA] Update prepared and stored');
    } catch (error) {
      console.error('[OTA] Prepare error:', error);
      throw error;
    }
  }

  /**
   * Install update (happens on next restart)
   */
  async installUpdate(manifest: UpdateManifest): Promise<void> {
    console.log(`[OTA] Installing update ${manifest.version}`);
    this.updateProgress.status = 'installing';
    this.notify();

    try {
      const db = await this.openUpdateDB();
      const tx = db.transaction('updates', 'readonly');
      const store = tx.objectStore('updates');

      // Get all files for this version
      const range = IDBKeyRange.bound(
        `file-${manifest.version}-`,
        `file-${manifest.version}-\uffff`
      );

      const files = await new Promise<any[]>((resolve, reject) => {
        const req = store.getAll(range);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });

      // Apply files to service worker
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.controller?.postMessage({
          type: 'INSTALL_UPDATE',
          files,
          version: manifest.version
        });
      }

      // Update version
      this.currentVersion = manifest.version;
      localStorage.setItem('appVersion', manifest.version);

      this.updateProgress.status = 'completed';
      this.updateProgress.progress = 100;
      this.notify();

      console.log('[OTA] Update installed successfully');

      // Notify user
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.ready;
        registration.showNotification('🎉 Mise à jour complète', {
          body: `Transfer ${manifest.version} est maintenant actif`,
          badge: '/badge-72x72.png'
        });
      }
    } catch (error) {
      console.error('[OTA] Install error:', error);
      this.updateProgress.status = 'failed';
      this.updateProgress.errorMessage = String(error);
      this.notify();
      throw error;
    }
  }

  /**
   * Rollback to previous version
   */
  async rollback(): Promise<void> {
    console.log('[OTA] Rolling back to previous version');
    try {
      const db = await this.openUpdateDB();
      const tx = db.transaction('versions', 'readonly');
      const store = tx.objectStore('versions');

      const versions = await new Promise<any[]>((resolve, reject) => {
        const req = store.getAll();
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });

      if (versions.length > 1) {
        const previousVersion = versions[versions.length - 2];
        await this.installUpdate(previousVersion);
      }
    } catch (error) {
      console.error('[OTA] Rollback error:', error);
      throw error;
    }
  }

  /**
   * Private helper methods
   */

  private async calculateSHA256(blob: Blob): Promise<string> {
    const buffer = await blob.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  private async storeUpdate(manifest: UpdateManifest, blob: Blob): Promise<void> {
    const db = await this.openUpdateDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('updates', 'readwrite');
      const store = tx.objectStore('updates');
      const req = store.put({
        key: `update-${manifest.version}`,
        blob,
        manifest,
        timestamp: Date.now(),
        installed: false
      });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  private async openUpdateDB(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open('transfer-updates', 1);

      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('updates')) {
          db.createObjectStore('updates', { keyPath: 'key' });
        }
        if (!db.objectStoreNames.contains('versions')) {
          db.createObjectStore('versions', { keyPath: 'version' });
        }
      };

      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  private scheduleDownload(manifest: UpdateManifest): void {
    // Schedule for WiFi + charging
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then(registration => {
        if ('periodicSync' in registration) {
          registration.periodicSync.register('check-updates', {
            minInterval: 24 * 60 * 60 * 1000 // 24 hours
          });
        }
      });
    }
  }

  private isUserInRollout(percentage: number): boolean {
    const deviceId = this.getDeviceId();
    const hash = parseInt(deviceId.substring(0, 8), 16);
    return (hash % 100) < percentage;
  }

  private compareVersions(v1: string, v2: string): number {
    const parts1 = v1.split('.').map(Number);
    const parts2 = v2.split('.').map(Number);

    for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
      const p1 = parts1[i] || 0;
      const p2 = parts2[i] || 0;
      if (p1 > p2) return 1;
      if (p1 < p2) return -1;
    }
    return 0;
  }

  private getPlatform(): string {
    const ua = navigator.userAgent;
    if (ua.includes('Android')) return 'android';
    if (ua.includes('iPhone') || ua.includes('iPad')) return 'ios';
    return 'web';
  }

  private getDeviceId(): string {
    let deviceId = localStorage.getItem('deviceId');
    if (!deviceId) {
      deviceId = 'device-' + Math.random().toString(36).substr(2, 9);
      localStorage.setItem('deviceId', deviceId);
    }
    return deviceId;
  }

  private notify(): void {
    this.listeners.forEach(listener => listener(this.updateProgress));
  }

  /**
   * Subscribe to updates
   */
  onProgress(callback: (progress: UpdateProgress) => void): () => void {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  getProgress(): UpdateProgress {
    return { ...this.updateProgress };
  }
}

export const otaUpdateManager = new OTAUpdateManager();

// ============================================================================
// REACT HOOK FOR UPDATE MANAGEMENT
// ============================================================================

import { useState, useEffect } from 'react';

export function useOTAUpdate() {
  const [progress, setProgress] = useState<UpdateProgress>(otaUpdateManager.getProgress());
  const [manifest, setManifest] = useState<UpdateManifest | null>(null);

  useEffect(() => {
    const unsubscribe = otaUpdateManager.onProgress(setProgress);
    otaUpdateManager.init();
    return unsubscribe;
  }, []);

  return {
    progress,
    manifest,
    checkForUpdates: () => otaUpdateManager.checkForUpdates().then(setManifest),
    installUpdate: (m: UpdateManifest) => otaUpdateManager.installUpdate(m),
    rollback: () => otaUpdateManager.rollback()
  };
}
