/**
 * TRANSFER PLATFORM - WALLET INTEGRATION
 * Trust Wallet, MetaMask, WalletConnect v2, Coinbase Wallet
 *
 * IMPORTANT SÉCURITÉ:
 * - Aucune clé privée n'est jamais demandée ni stockée ici.
 * - Connexion via WalletConnect / injected provider = signature côté wallet uniquement.
 * - Le backend ne voit que l'adresse publique et les transactions signées.
 */

import { useState, useEffect, useCallback } from 'react';

// ============================================================================
// TYPES
// ============================================================================

interface WalletInfo {
  address: string;
  chainId: number;
  provider: 'trustwallet' | 'metamask' | 'walletconnect' | 'coinbase';
  balance?: string;
  connected: boolean;
}

interface SupportedChain {
  chainId: number;
  name: string;
  currency: string;
  rpcUrl: string;
  explorer: string;
}

const SUPPORTED_CHAINS: SupportedChain[] = [
  { chainId: 137, name: 'Polygon', currency: 'MATIC', rpcUrl: 'https://polygon-rpc.com', explorer: 'https://polygonscan.com' },
  { chainId: 56, name: 'BNB Chain', currency: 'BNB', rpcUrl: 'https://bsc-dataseed.binance.org', explorer: 'https://bscscan.com' },
  { chainId: 1, name: 'Ethereum', currency: 'ETH', rpcUrl: 'https://eth.llamarpc.com', explorer: 'https://etherscan.io' },
];

// USDC contract addresses by chain
const USDC_CONTRACTS: Record<number, string> = {
  137: '0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174', // Polygon
  56: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',  // BSC (BUSD-like)
  1: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',   // Ethereum
};

// ============================================================================
// WALLET CONNECTION MANAGER
// ============================================================================

class WalletManager {
  private currentWallet: WalletInfo | null = null;
  private listeners: Set<(wallet: WalletInfo | null) => void> = new Set();

  /**
   * Connect via injected provider (Trust Wallet browser extension/app, MetaMask)
   * Trust Wallet mobile injects window.ethereum just like MetaMask when opened
   * inside its in-app browser (dApp browser).
   */
  async connectInjected(): Promise<WalletInfo> {
    const eth = (window as any).ethereum;

    if (!eth) {
      throw new Error(
        'Aucun wallet détecté. Ouvre ce site dans le navigateur intégré de Trust Wallet, ou installe MetaMask.'
      );
    }

    const accounts: string[] = await eth.request({ method: 'eth_requestAccounts' });
    const chainIdHex: string = await eth.request({ method: 'eth_chainId' });

    const wallet: WalletInfo = {
      address: accounts[0],
      chainId: parseInt(chainIdHex, 16),
      provider: eth.isTrust ? 'trustwallet' : eth.isMetaMask ? 'metamask' : 'metamask',
      connected: true,
    };

    this.currentWallet = wallet;
    this.notify();

    // Listen for account/chain changes
    eth.on('accountsChanged', (accs: string[]) => {
      if (accs.length === 0) {
        this.disconnect();
      } else {
        this.currentWallet = { ...this.currentWallet!, address: accs[0] };
        this.notify();
      }
    });

    eth.on('chainChanged', (chainIdHex: string) => {
      this.currentWallet = { ...this.currentWallet!, chainId: parseInt(chainIdHex, 16) };
      this.notify();
    });

    await this.refreshBalance();
    return wallet;
  }

  /**
   * Connect via WalletConnect v2 (QR code / deep link) — works with Trust Wallet,
   * Rainbow, Coinbase Wallet, and 300+ others without needing their extension.
   */
  async connectWalletConnect(projectId: string): Promise<WalletInfo> {
    // Requires: npm install @walletconnect/ethereum-provider
    const { EthereumProvider } = await import('@walletconnect/ethereum-provider');

    const provider = await EthereumProvider.init({
      projectId, // from https://cloud.walletconnect.com
      chains: [137],
      optionalChains: [1, 56],
      showQrModal: true,
      metadata: {
        name: 'TRANSFER Platform',
        description: 'African fintech transfer platform',
        url: 'https://transfer.app',
        icons: ['https://transfer.app/icon.png'],
      },
    });

    await provider.connect();

    const accounts = provider.accounts;
    const chainId = provider.chainId;

    const wallet: WalletInfo = {
      address: accounts[0],
      chainId: chainId!,
      provider: 'walletconnect',
      connected: true,
    };

    this.currentWallet = wallet;
    (window as any).__wcProvider = provider; // keep reference for signing later
    this.notify();

    provider.on('disconnect', () => this.disconnect());

    return wallet;
  }

  /**
   * Switch to Polygon (recommended for low-fee USDC withdrawals)
   */
  async switchToPolygon(): Promise<void> {
    const eth = (window as any).ethereum;
    if (!eth) throw new Error('Wallet non connecté');

    try {
      await eth.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: '0x89' }], // 137 in hex
      });
    } catch (error: any) {
      if (error.code === 4902) {
        // Chain not added yet — add it
        await eth.request({
          method: 'wallet_addEthereumChain',
          params: [{
            chainId: '0x89',
            chainName: 'Polygon',
            nativeCurrency: { name: 'MATIC', symbol: 'MATIC', decimals: 18 },
            rpcUrls: ['https://polygon-rpc.com'],
            blockExplorerUrls: ['https://polygonscan.com'],
          }],
        });
      } else {
        throw error;
      }
    }
  }

  /**
   * Get native + USDC balance for the connected wallet
   */
  async refreshBalance(): Promise<string> {
    if (!this.currentWallet) throw new Error('Aucun wallet connecté');

    const eth = (window as any).ethereum;
    const balanceHex: string = await eth.request({
      method: 'eth_getBalance',
      params: [this.currentWallet.address, 'latest'],
    });

    const balanceWei = BigInt(balanceHex);
    const balanceNative = (Number(balanceWei) / 1e18).toFixed(4);

    this.currentWallet.balance = balanceNative;
    this.notify();
    return balanceNative;
  }

  /**
   * Get USDC balance via contract call (balanceOf)
   */
  async getUSDCBalance(): Promise<string> {
    if (!this.currentWallet) throw new Error('Aucun wallet connecté');

    const eth = (window as any).ethereum;
    const contract = USDC_CONTRACTS[this.currentWallet.chainId];
    if (!contract) throw new Error('USDC non supporté sur cette chaîne');

    // balanceOf(address) function selector: 0x70a08231
    const paddedAddress = this.currentWallet.address.slice(2).padStart(64, '0');
    const data = `0x70a08231${paddedAddress}`;

    const result: string = await eth.request({
      method: 'eth_call',
      params: [{ to: contract, data }, 'latest'],
    });

    const balance = BigInt(result);
    return (Number(balance) / 1e6).toFixed(2); // USDC has 6 decimals
  }

  /**
   * Send USDC to a TRANSFER platform deposit address
   * This is how a user tops up their TRANSFER balance from their own wallet.
   */
  async depositUSDC(toAddress: string, amount: number): Promise<string> {
    if (!this.currentWallet) throw new Error('Aucun wallet connecté');

    const eth = (window as any).ethereum;
    const contract = USDC_CONTRACTS[this.currentWallet.chainId];

    // transfer(address,uint256) function selector: 0xa9059cbb
    const amountUnits = BigInt(Math.round(amount * 1e6)); // USDC 6 decimals
    const paddedTo = toAddress.slice(2).padStart(64, '0');
    const paddedAmount = amountUnits.toString(16).padStart(64, '0');
    const data = `0xa9059cbb${paddedTo}${paddedAmount}`;

    const txHash: string = await eth.request({
      method: 'eth_sendTransaction',
      params: [{
        from: this.currentWallet.address,
        to: contract,
        data,
      }],
    });

    return txHash; // Confirm this hash server-side before crediting the platform balance
  }

  /**
   * Sign a message to prove wallet ownership (used to link wallet to a TRANSFER account,
   * no funds move — pure signature for authentication)
   */
  async signOwnershipProof(userId: string): Promise<{ message: string; signature: string }> {
    if (!this.currentWallet) throw new Error('Aucun wallet connecté');

    const eth = (window as any).ethereum;
    const message = `TRANSFER Platform - Lier ce wallet au compte ${userId}\nHorodatage: ${Date.now()}`;

    const signature: string = await eth.request({
      method: 'personal_sign',
      params: [message, this.currentWallet.address],
    });

    return { message, signature };
  }

  disconnect(): void {
    this.currentWallet = null;
    this.notify();
  }

  getWallet(): WalletInfo | null {
    return this.currentWallet;
  }

  onChange(callback: (wallet: WalletInfo | null) => void): () => void {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  private notify(): void {
    this.listeners.forEach(cb => cb(this.currentWallet));
  }
}

export const walletManager = new WalletManager();

// ============================================================================
// REACT HOOK
// ============================================================================

export function useWallet() {
  const [wallet, setWallet] = useState<WalletInfo | null>(walletManager.getWallet());
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => walletManager.onChange(setWallet), []);

  const connectTrustWallet = useCallback(async () => {
    setIsConnecting(true);
    setError(null);
    try {
      // Trust Wallet mobile app browser injects window.ethereum directly
      await walletManager.connectInjected();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setIsConnecting(false);
    }
  }, []);

  const connectViaQR = useCallback(async (walletConnectProjectId: string) => {
    setIsConnecting(true);
    setError(null);
    try {
      await walletManager.connectWalletConnect(walletConnectProjectId);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setIsConnecting(false);
    }
  }, []);

  return {
    wallet,
    isConnecting,
    error,
    connectTrustWallet,
    connectViaQR,
    disconnect: () => walletManager.disconnect(),
    switchToPolygon: () => walletManager.switchToPolygon(),
    getUSDCBalance: () => walletManager.getUSDCBalance(),
    depositUSDC: (to: string, amount: number) => walletManager.depositUSDC(to, amount),
    linkWalletToAccount: (userId: string) => walletManager.signOwnershipProof(userId),
  };
}

// ============================================================================
// UI COMPONENT
// ============================================================================

import React from 'react';

export function WalletConnectButton({ userId, onLinked }: { userId: string; onLinked?: (address: string) => void }) {
  const { wallet, isConnecting, error, connectTrustWallet, connectViaQR, disconnect, linkWalletToAccount } = useWallet();
  const [showOptions, setShowOptions] = useState(false);

  const handleLink = async () => {
    const proof = await linkWalletToAccount(userId);
    // Send proof.message + proof.signature to your backend to verify + store the link
    await fetch('/api/wallets/link', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, ...proof, address: wallet?.address }),
    });
    onLinked?.(wallet!.address);
  };

  if (wallet?.connected) {
    return (
      <div className="bg-black/30 border border-green-500/30 rounded-lg p-3 text-sm">
        <div className="flex justify-between items-center">
          <div>
            <div className="text-green-400 font-bold">✓ {wallet.provider}</div>
            <div className="text-xs text-gray-400 font-mono">
              {wallet.address.slice(0, 6)}...{wallet.address.slice(-4)}
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={handleLink} className="bg-blue-500 px-3 py-1 rounded text-xs">
              Lier au compte
            </button>
            <button onClick={disconnect} className="bg-red-500/70 px-3 py-1 rounded text-xs">
              Déconnecter
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <button
        onClick={() => setShowOptions(!showOptions)}
        disabled={isConnecting}
        className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold py-3 rounded-lg"
      >
        {isConnecting ? '⟳ Connexion...' : '🔗 Connecter un Wallet'}
      </button>

      {showOptions && (
        <div className="mt-2 space-y-2">
          <button
            onClick={connectTrustWallet}
            className="w-full bg-black/30 border border-blue-500/30 rounded p-3 text-sm text-left flex items-center gap-2"
          >
            🛡️ Trust Wallet (navigateur intégré)
          </button>
          <button
            onClick={() => connectViaQR(process.env.REACT_APP_WALLETCONNECT_PROJECT_ID || '')}
            className="w-full bg-black/30 border border-blue-500/30 rounded p-3 text-sm text-left flex items-center gap-2"
          >
            📱 WalletConnect (QR code — Trust Wallet, Coinbase, autres)
          </button>
        </div>
      )}

      {error && <div className="text-red-400 text-xs mt-2">{error}</div>}
    </div>
  );
}
