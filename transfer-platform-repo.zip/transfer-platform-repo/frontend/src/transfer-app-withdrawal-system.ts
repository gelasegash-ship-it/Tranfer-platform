/**
 * TRANSFER PLATFORM - WITHDRAWAL SYSTEM
 * Complete cash-out functionality with multiple payment partners
 * 
 * Supported Methods:
 * - Mobile Money (MTN, Airtel, Orange)
 * - Bank Transfer
 * - Crypto Withdrawal (USDC, Bitcoin)
 * - Cash Agent Network
 */

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

interface WithdrawalMethod {
  id: string;
  name: string;
  type: 'mobile_money' | 'bank' | 'crypto' | 'agent';
  provider: string;
  fee: number; // percentage
  minAmount: number;
  maxAmount: number;
  currency: string;
  processingTime: string;
  icon: string;
  available: boolean;
  countries: string[];
}

interface Withdrawal {
  id: string;
  userId: string;
  methodId: string;
  method: WithdrawalMethod;
  amount: number;
  currency: string;
  fee: number;
  netAmount: number;
  status: 'pending' | 'approved' | 'processing' | 'completed' | 'failed' | 'cancelled';
  recipient: {
    type: string;
    identifier: string; // Phone, Account, Wallet Address
    name?: string;
  };
  reference: string;
  transactionHash?: string; // For crypto
  bankReference?: string; // For bank transfers
  failureReason?: string;
  createdAt: Date;
  completedAt?: Date;
  expiresAt: Date;
}

interface WithdrawalLimit {
  daily: number;
  weekly: number;
  monthly: number;
  dailyUsed: number;
  weeklyUsed: number;
  monthlyUsed: number;
  kycLevel: 'basic' | 'verified' | 'premium';
}

// ============================================================================
// WITHDRAWAL SERVICE
// ============================================================================

class WithdrawalService {
  private baseURL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';
  private token: string | null = null;

  setToken(token: string) {
    this.token = token;
  }

  private getHeaders() {
    return {
      'Content-Type': 'application/json',
      ...(this.token && { 'Authorization': `Bearer ${this.token}` })
    };
  }

  /**
   * Get available withdrawal methods based on user location and KYC level
   */
  async getAvailableMethods(country: string, kycLevel: string): Promise<WithdrawalMethod[]> {
    const res = await fetch(`${this.baseURL}/withdrawals/methods?country=${country}&kyc=${kycLevel}`, {
      headers: this.getHeaders()
    });
    return res.json();
  }

  /**
   * Get withdrawal limits for current user
   */
  async getWithdrawalLimits(): Promise<WithdrawalLimit> {
    const res = await fetch(`${this.baseURL}/withdrawals/limits`, {
      headers: this.getHeaders()
    });
    return res.json();
  }

  /**
   * Calculate withdrawal fees and net amount
   */
  async calculateWithdrawal(methodId: string, amount: number): Promise<{
    amount: number;
    fee: number;
    netAmount: number;
    exchangeRate?: number;
    finalCurrency?: string;
  }> {
    const res = await fetch(`${this.baseURL}/withdrawals/calculate`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ methodId, amount })
    });
    return res.json();
  }

  /**
   * Validate recipient identifier (phone, account, wallet)
   */
  async validateRecipient(methodId: string, identifier: string): Promise<{
    valid: boolean;
    name?: string;
    error?: string;
  }> {
    const res = await fetch(`${this.baseURL}/withdrawals/validate-recipient`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ methodId, identifier })
    });
    return res.json();
  }

  /**
   * Initiate withdrawal request
   */
  async createWithdrawal(data: {
    methodId: string;
    amount: number;
    currency: string;
    recipient: {
      type: string;
      identifier: string;
      name?: string;
    };
    pin?: string;
  }): Promise<Withdrawal> {
    const res = await fetch(`${this.baseURL}/withdrawals`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data)
    });

    if (!res.ok) {
      const error = await res.json();
      throw new Error(error.message || 'Withdrawal failed');
    }

    return res.json();
  }

  /**
   * Confirm withdrawal with OTP
   */
  async confirmWithdrawal(withdrawalId: string, otp: string): Promise<Withdrawal> {
    const res = await fetch(`${this.baseURL}/withdrawals/${withdrawalId}/confirm`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ otp })
    });

    if (!res.ok) {
      const error = await res.json();
      throw new Error(error.message || 'Confirmation failed');
    }

    return res.json();
  }

  /**
   * Get withdrawal history
   */
  async getWithdrawalHistory(limit: number = 20): Promise<Withdrawal[]> {
    const res = await fetch(`${this.baseURL}/withdrawals?limit=${limit}`, {
      headers: this.getHeaders()
    });
    return res.json();
  }

  /**
   * Get withdrawal status
   */
  async getWithdrawalStatus(withdrawalId: string): Promise<Withdrawal> {
    const res = await fetch(`${this.baseURL}/withdrawals/${withdrawalId}`, {
      headers: this.getHeaders()
    });
    return res.json();
  }

  /**
   * Cancel pending withdrawal
   */
  async cancelWithdrawal(withdrawalId: string): Promise<Withdrawal> {
    const res = await fetch(`${this.baseURL}/withdrawals/${withdrawalId}/cancel`, {
      method: 'POST',
      headers: this.getHeaders()
    });
    return res.json();
  }

  /**
   * Get agent network locations for cash pickup
   */
  async getAgentLocations(lat: number, lng: number, radius: number = 5): Promise<any[]> {
    const res = await fetch(
      `${this.baseURL}/withdrawals/agents?lat=${lat}&lng=${lng}&radius=${radius}`,
      { headers: this.getHeaders() }
    );
    return res.json();
  }
}

export const withdrawalService = new WithdrawalService();

// ============================================================================
// AVAILABLE WITHDRAWAL METHODS (Default Config)
// ============================================================================

export const WITHDRAWAL_METHODS: Record<string, WithdrawalMethod[]> = {
  'congo': [
    {
      id: 'mtn-congo',
      name: 'MTN Mobile Money',
      type: 'mobile_money',
      provider: 'MTN Congo',
      fee: 2.5,
      minAmount: 1000,
      maxAmount: 5000000,
      currency: 'XAF',
      processingTime: 'Instant',
      icon: '📱',
      available: true,
      countries: ['CG']
    },
    {
      id: 'airtel-congo',
      name: 'Airtel Money',
      type: 'mobile_money',
      provider: 'Airtel Congo',
      fee: 2.5,
      minAmount: 1000,
      maxAmount: 5000000,
      currency: 'XAF',
      processingTime: 'Instant',
      icon: '📱',
      available: true,
      countries: ['CG']
    },
    {
      id: 'bank-congo',
      name: 'Bank Transfer',
      type: 'bank',
      provider: 'BGFIBANK',
      fee: 5,
      minAmount: 10000,
      maxAmount: 100000000,
      currency: 'XAF',
      processingTime: '1-2 jours',
      icon: '🏦',
      available: true,
      countries: ['CG']
    },
    {
      id: 'usdc-polygon',
      name: 'USDC (Polygon)',
      type: 'crypto',
      provider: 'Polygon Network',
      fee: 1,
      minAmount: 10,
      maxAmount: 100000,
      currency: 'USD',
      processingTime: '5-15 minutes',
      icon: '⛓️',
      available: true,
      countries: ['CG', 'CI', 'SN']
    },
    {
      id: 'agent-network',
      name: 'Cash Pickup (Agent)',
      type: 'agent',
      provider: 'Transfer Agent Network',
      fee: 3,
      minAmount: 5000,
      maxAmount: 10000000,
      currency: 'XAF',
      processingTime: 'Instant',
      icon: '🏪',
      available: true,
      countries: ['CG', 'CI', 'SN', 'BJ', 'ML', 'BF', 'TG', 'NE']
    }
  ],
  'senegal': [
    {
      id: 'orange-senegal',
      name: 'Orange Money',
      type: 'mobile_money',
      provider: 'Orange Senegal',
      fee: 2,
      minAmount: 500,
      maxAmount: 3000000,
      currency: 'XOF',
      processingTime: 'Instant',
      icon: '📱',
      available: true,
      countries: ['SN']
    },
    {
      id: 'wave-senegal',
      name: 'Wave',
      type: 'mobile_money',
      provider: 'Wave',
      fee: 1.5,
      minAmount: 100,
      maxAmount: 5000000,
      currency: 'XOF',
      processingTime: 'Instant',
      icon: '📱',
      available: true,
      countries: ['SN', 'CI', 'ML', 'BJ']
    }
  ],
  'nigeria': [
    {
      id: 'flutterwave',
      name: 'Flutterwave',
      type: 'mobile_money',
      provider: 'Flutterwave',
      fee: 1.5,
      minAmount: 1000,
      maxAmount: 50000000,
      currency: 'NGN',
      processingTime: 'Instant',
      icon: '📱',
      available: true,
      countries: ['NG']
    },
    {
      id: 'paystack',
      name: 'Paystack Bank',
      type: 'bank',
      provider: 'Paystack',
      fee: 2,
      minAmount: 5000,
      maxAmount: 100000000,
      currency: 'NGN',
      processingTime: '1-3 heures',
      icon: '🏦',
      available: true,
      countries: ['NG', 'GH']
    }
  ]
};

// ============================================================================
// MOCK IMPLEMENTATION (For offline/demo)
// ============================================================================

export const mockWithdrawalMethods: WithdrawalMethod[] = WITHDRAWAL_METHODS['congo'];

export async function mockCalculateWithdrawal(methodId: string, amount: number) {
  const method = mockWithdrawalMethods.find((m) => m.id === methodId);
  if (!method) throw new Error('Method not found');

  const fee = Math.round((amount * method.fee) / 100);
  const netAmount = amount - fee;

  return {
    amount,
    fee,
    netAmount,
    exchangeRate: methodId.includes('usdc') ? 600 : undefined,
    finalCurrency: methodId.includes('usdc') ? 'USD' : method.currency
  };
}

export async function mockValidateRecipient(methodId: string, identifier: string) {
  // Simulate validation
  const isValid = /^\+?[0-9]{9,15}$/.test(identifier) || /^0x[a-fA-F0-9]{40}$/.test(identifier);

  if (!isValid) {
    return { valid: false, error: 'Invalid recipient format' };
  }

  // Mock name lookup
  const names = ['Jean Dupont', 'Marie Diallo', 'Pierre N\'Dour', 'Fatou Sow'];
  const name = names[Math.floor(Math.random() * names.length)];

  return { valid: true, name };
}

export async function mockCreateWithdrawal(data: any): Promise<Withdrawal> {
  return {
    id: `WD-${Date.now()}`,
    userId: 'user-123',
    methodId: data.methodId,
    method: mockWithdrawalMethods.find((m) => m.id === data.methodId)!,
    amount: data.amount,
    currency: data.currency,
    fee: Math.round((data.amount * 2.5) / 100),
    netAmount: data.amount - Math.round((data.amount * 2.5) / 100),
    status: 'pending',
    recipient: data.recipient,
    reference: `REF-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
    createdAt: new Date(),
    expiresAt: new Date(Date.now() + 15 * 60 * 1000) // 15 minutes
  };
}

export async function mockConfirmWithdrawal(withdrawalId: string, otp: string): Promise<Withdrawal> {
  // Simulate OTP validation
  if (!/^\d{6}$/.test(otp)) {
    throw new Error('Invalid OTP format');
  }

  return {
    id: withdrawalId,
    userId: 'user-123',
    methodId: 'mtn-congo',
    method: mockWithdrawalMethods[0],
    amount: 100000,
    currency: 'XAF',
    fee: 2500,
    netAmount: 97500,
    status: 'processing',
    recipient: { type: 'phone', identifier: '+243700000000' },
    reference: 'REF-ABC123',
    createdAt: new Date(),
    expiresAt: new Date(Date.now() + 15 * 60 * 1000)
  };
}
