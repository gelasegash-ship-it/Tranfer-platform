/**
 * TRANSFER PLATFORM - MONETIZATION & REVENUE SYSTEM
 * Multiple revenue streams for users and platform
 * 
 * Features:
 * - Referral program (multi-level)
 * - Agent network commission
 * - Interest on balance
 * - Premium subscriptions
 * - Affiliate marketing
 * - Creator rewards
 * - Staking & yield
 */

// ============================================================================
// MONETIZATION TYPES
// ============================================================================

interface ReferralReward {
  id: string;
  referrerId: string;
  referredId: string;
  status: 'pending' | 'qualified' | 'paid';
  amount: number;
  level: number; // 1, 2, 3 (multi-level)
  commission: number; // percentage
  createdAt: Date;
  qualifiedAt?: Date;
  paidAt?: Date;
}

interface SubscriptionTier {
  id: string;
  name: string;
  price: number; // monthly
  currency: string;
  features: string[];
  limits: {
    dailyTransfers: number;
    monthlyVolume: number;
    prioritySupport: boolean;
    customReports: boolean;
    apiAccess: boolean;
  };
}

interface UserRevenue {
  userId: string;
  referralEarnings: number;
  agentCommissions: number;
  interestEarned: number;
  premiumSubscription: {
    tier: string;
    active: boolean;
    renews: Date;
  };
  affiliateEarnings: number;
  creatorRewards: number;
  stakingYield: number;
  totalMonthly: number;
  totalAllTime: number;
}

interface AffiliateLink {
  id: string;
  userId: string;
  code: string;
  url: string;
  clicks: number;
  conversions: number;
  earnings: number;
  createdAt: Date;
}

interface CreatorContent {
  id: string;
  creatorId: string;
  type: 'video' | 'guide' | 'tutorial' | 'testimonial';
  title: string;
  description: string;
  url?: string;
  embedCode?: string;
  views: number;
  shares: number;
  rating: number;
  earnings: number;
  approvedAt: Date;
}

// ============================================================================
// MONETIZATION SERVICE
// ============================================================================

class MonetizationEngine {
  private baseURL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';
  private token: string | null = null;

  private REFERRAL_RATES = {
    level1: 0.05, // 5% of first transfer fee
    level2: 0.02, // 2% of second level
    level3: 0.01   // 1% of third level
  };

  private SUBSCRIPTION_TIERS: SubscriptionTier[] = [
    {
      id: 'free',
      name: 'Gratuit',
      price: 0,
      currency: 'XAF',
      features: ['Transferts basiques', 'Support email'],
      limits: {
        dailyTransfers: 5,
        monthlyVolume: 5000000,
        prioritySupport: false,
        customReports: false,
        apiAccess: false
      }
    },
    {
      id: 'pro',
      name: 'Pro',
      price: 9990,
      currency: 'XAF',
      features: ['Transferts illimités', 'Support prioritaire', 'Rapports personnalisés'],
      limits: {
        dailyTransfers: 100,
        monthlyVolume: 500000000,
        prioritySupport: true,
        customReports: true,
        apiAccess: false
      }
    },
    {
      id: 'business',
      name: 'Business',
      price: 49990,
      currency: 'XAF',
      features: ['Tout de Pro', 'API access', 'Webhook integrations', 'White label'],
      limits: {
        dailyTransfers: 1000,
        monthlyVolume: 10000000000,
        prioritySupport: true,
        customReports: true,
        apiAccess: true
      }
    }
  ];

  setToken(token: string) {
    this.token = token;
  }

  private getHeaders() {
    return {
      'Content-Type': 'application/json',
      ...(this.token && { 'Authorization': `Bearer ${this.token}` })
    };
  }

  /**
   * REFERRAL PROGRAM
   */

  async generateReferralLink(userId: string): Promise<string> {
    const code = this.generateReferralCode();
    const link = `${window.location.origin}?ref=${code}`;

    await fetch(`${this.baseURL}/referrals/create`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ userId, code })
    });

    return link;
  }

  async trackReferral(referralCode: string, newUserId: string): Promise<void> {
    await fetch(`${this.baseURL}/referrals/track`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ referralCode, newUserId })
    });
  }

  async getReferralEarnings(userId: string): Promise<ReferralReward[]> {
    const res = await fetch(`${this.baseURL}/referrals/earnings/${userId}`, {
      headers: this.getHeaders()
    });
    return res.json();
  }

  async claimReferralEarnings(userId: string): Promise<number> {
    const res = await fetch(`${this.baseURL}/referrals/claim`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ userId })
    });
    const data = await res.json();
    return data.amount;
  }

  /**
   * AGENT NETWORK COMMISSION
   */

  async registerAsAgent(userId: string, location: { lat: number; lng: number }): Promise<void> {
    await fetch(`${this.baseURL}/agents/register`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ userId, location })
    });
  }

  async getAgentStats(userId: string): Promise<{
    transactionsProcessed: number;
    commissionsEarned: number;
    monthlyRevenue: number;
    customerCount: number;
  }> {
    const res = await fetch(`${this.baseURL}/agents/stats/${userId}`, {
      headers: this.getHeaders()
    });
    return res.json();
  }

  async getNearbyAgents(lat: number, lng: number): Promise<any[]> {
    const res = await fetch(
      `${this.baseURL}/agents/nearby?lat=${lat}&lng=${lng}`,
      { headers: this.getHeaders() }
    );
    return res.json();
  }

  /**
   * INTEREST & SAVINGS
   */

  async getInterestRate(): Promise<{ daily: number; monthly: number }> {
    const res = await fetch(`${this.baseURL}/interest/rates`, {
      headers: this.getHeaders()
    });
    return res.json();
  }

  async getAccruedInterest(userId: string): Promise<number> {
    const res = await fetch(`${this.baseURL}/interest/accrued/${userId}`, {
      headers: this.getHeaders()
    });
    const data = await res.json();
    return data.amount;
  }

  async claimInterest(userId: string): Promise<number> {
    const res = await fetch(`${this.baseURL}/interest/claim`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ userId })
    });
    const data = await res.json();
    return data.amount;
  }

  /**
   * SUBSCRIPTION MANAGEMENT
   */

  getSubscriptionTiers(): SubscriptionTier[] {
    return this.SUBSCRIPTION_TIERS;
  }

  async subscribe(userId: string, tierId: string): Promise<{
    subscription: any;
    nextBillingDate: Date;
  }> {
    const res = await fetch(`${this.baseURL}/subscriptions/create`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ userId, tierId })
    });
    return res.json();
  }

  async getUserSubscription(userId: string): Promise<any> {
    const res = await fetch(`${this.baseURL}/subscriptions/${userId}`, {
      headers: this.getHeaders()
    });
    return res.json();
  }

  /**
   * AFFILIATE PROGRAM
   */

  async createAffiliateLink(userId: string): Promise<AffiliateLink> {
    const res = await fetch(`${this.baseURL}/affiliates/create`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ userId })
    });
    return res.json();
  }

  async trackAffiliateClick(affiliateCode: string): Promise<void> {
    await fetch(`${this.baseURL}/affiliates/click`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ affiliateCode })
    });
  }

  async getAffiliateStats(userId: string): Promise<{
    totalLinks: number;
    totalClicks: number;
    totalConversions: number;
    totalEarnings: number;
  }> {
    const res = await fetch(`${this.baseURL}/affiliates/stats/${userId}`, {
      headers: this.getHeaders()
    });
    return res.json();
  }

  /**
   * CREATOR REWARDS
   */

  async submitCreatorContent(creatorId: string, content: Omit<CreatorContent, 'id' | 'views' | 'shares' | 'rating' | 'earnings' | 'approvedAt' | 'creatorId'>): Promise<CreatorContent> {
    const res = await fetch(`${this.baseURL}/creators/submit`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ creatorId, ...content })
    });
    return res.json();
  }

  async getCreatorContent(creatorId: string): Promise<CreatorContent[]> {
    const res = await fetch(`${this.baseURL}/creators/content/${creatorId}`, {
      headers: this.getHeaders()
    });
    return res.json();
  }

  async getCreatorEarnings(creatorId: string): Promise<number> {
    const res = await fetch(`${this.baseURL}/creators/earnings/${creatorId}`, {
      headers: this.getHeaders()
    });
    const data = await res.json();
    return data.totalEarnings;
  }

  /**
   * STAKING & YIELD
   */

  async getStakingInfo(): Promise<{
    apr: number;
    minStake: number;
    lockPeriod: number;
  }> {
    const res = await fetch(`${this.baseURL}/staking/info`, {
      headers: this.getHeaders()
    });
    return res.json();
  }

  async stake(userId: string, amount: number): Promise<void> {
    await fetch(`${this.baseURL}/staking/stake`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ userId, amount })
    });
  }

  async getStakingYield(userId: string): Promise<number> {
    const res = await fetch(`${this.baseURL}/staking/yield/${userId}`, {
      headers: this.getHeaders()
    });
    const data = await res.json();
    return data.yield;
  }

  /**
   * COMPREHENSIVE REVENUE DASHBOARD
   */

  async getUserRevenue(userId: string): Promise<UserRevenue> {
    const res = await fetch(`${this.baseURL}/revenue/summary/${userId}`, {
      headers: this.getHeaders()
    });
    return res.json();
  }

  async withdrawEarnings(userId: string, amount: number, method: string): Promise<{
    withdrawalId: string;
    status: string;
  }> {
    const res = await fetch(`${this.baseURL}/revenue/withdraw`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify({ userId, amount, method })
    });
    return res.json();
  }

  /**
   * PRIVATE HELPERS
   */

  private generateReferralCode(): string {
    return 'REF-' + Math.random().toString(36).substr(2, 9).toUpperCase();
  }
}

export const monetizationEngine = new MonetizationEngine();

// ============================================================================
// REACT HOOKS FOR MONETIZATION
// ============================================================================

import { useState, useCallback, useEffect } from 'react';

export function useReferralProgram(userId: string) {
  const [referralLink, setReferralLink] = useState('');
  const [earnings, setEarnings] = useState<ReferralReward[]>([]);
  const [totalEarnings, setTotalEarnings] = useState(0);

  useEffect(() => {
    loadReferralData();
  }, [userId]);

  const loadReferralData = useCallback(async () => {
    try {
      const link = await monetizationEngine.generateReferralLink(userId);
      const rewards = await monetizationEngine.getReferralEarnings(userId);
      
      setReferralLink(link);
      setEarnings(rewards);
      setTotalEarnings(rewards.reduce((sum, r) => sum + r.amount, 0));
    } catch (error) {
      console.error('Error loading referral data:', error);
    }
  }, [userId]);

  const claimEarnings = useCallback(async () => {
    try {
      const amount = await monetizationEngine.claimReferralEarnings(userId);
      setTotalEarnings(prev => prev + amount);
      await loadReferralData();
      return amount;
    } catch (error) {
      console.error('Error claiming earnings:', error);
      throw error;
    }
  }, [userId, loadReferralData]);

  return {
    referralLink,
    earnings,
    totalEarnings,
    claimEarnings,
    refresh: loadReferralData
  };
}

export function useAgentNetwork(userId: string) {
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    monetizationEngine.getAgentStats(userId).then(setStats);
  }, [userId]);

  return {
    stats,
    registerAsAgent: (location: any) => monetizationEngine.registerAsAgent(userId, location)
  };
}

export function useSubscription(userId: string) {
  const [subscription, setSubscription] = useState<any>(null);
  const [tiers] = useState(monetizationEngine.getSubscriptionTiers());

  useEffect(() => {
    monetizationEngine.getUserSubscription(userId).then(setSubscription);
  }, [userId]);

  return {
    subscription,
    tiers,
    subscribe: (tierId: string) => monetizationEngine.subscribe(userId, tierId)
  };
}

export function useRevenueDashboard(userId: string) {
  const [revenue, setRevenue] = useState<UserRevenue | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const refresh = useCallback(async () => {
    setIsLoading(true);
    try {
      const data = await monetizationEngine.getUserRevenue(userId);
      setRevenue(data);
    } finally {
      setIsLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    refresh();
  }, [userId, refresh]);

  return {
    revenue,
    isLoading,
    refresh,
    withdraw: (amount: number, method: string) => 
      monetizationEngine.withdrawEarnings(userId, amount, method)
  };
}
