/**
 * TRANSFER PLATFORM - ADVANCED UI COMPONENTS
 * Custom scrollable messages, AI chat, analytics with smooth animations
 * 
 * Features:
 * - Custom message scroll with momentum
 * - Real-time AI chat interface
 * - Analytics dashboard
 * - Animated transitions
 * - Gesture-based interactions
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useAI, type AIInsight } from './transfer-app-revolutionary-ai';

// ============================================================================
// CUSTOM SCROLLABLE MESSAGE COMPONENT
// ============================================================================

export function CustomScrollableMessages({
  messages,
  onLoadMore,
  isLoading
}: {
  messages: any[];
  onLoadMore?: () => void;
  isLoading?: boolean;
}) {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [scrollY, setScrollY] = useState(0);
  const [showScrollToBottom, setShowScrollToBottom] = useState(false);
  const [velocity, setVelocity] = useState(0);
  const lastScrollTimeRef = useRef(0);
  const lastScrollYRef = useRef(0);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const container = e.currentTarget;
    const currentScrollY = container.scrollTop;
    const currentTime = Date.now();
    const timeDelta = currentTime - lastScrollTimeRef.current;

    // Calculate velocity
    if (timeDelta > 0) {
      const newVelocity = (lastScrollYRef.current - currentScrollY) / timeDelta;
      setVelocity(newVelocity);
    }

    setScrollY(currentScrollY);
    lastScrollYRef.current = currentScrollY;
    lastScrollTimeRef.current = currentTime;

    // Show scroll to bottom button if not at bottom
    const isAtBottom = 
      currentScrollY + container.clientHeight >= container.scrollHeight - 50;
    setShowScrollToBottom(!isAtBottom);

    // Load more on scroll to top
    if (currentScrollY < 100 && onLoadMore && !isLoading) {
      onLoadMore();
    }
  };

  const scrollToBottom = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({
        top: scrollContainerRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  return (
    <div className="relative h-full">
      <div
        ref={scrollContainerRef}
        onScroll={handleScroll}
        className="h-full overflow-y-auto scroll-smooth"
        style={{
          scrollBehavior: 'smooth',
          WebkitOverflowScrolling: 'touch'
        }}
      >
        {/* Loading indicator at top */}
        {isLoading && (
          <div className="flex justify-center py-4">
            <div className="animate-spin">
              <div className="w-6 h-6 border-3 border-blue-200 border-t-blue-500 rounded-full" />
            </div>
          </div>
        )}

        {/* Messages */}
        <div className="space-y-2 p-4">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fadeIn`}
            >
              <div
                className={`max-w-xs px-4 py-2 rounded-2xl transition-all duration-300 ${
                  msg.role === 'user'
                    ? 'bg-blue-500 text-white rounded-br-none'
                    : 'bg-gray-200 text-gray-800 rounded-bl-none'
                }`}
              >
                <p className="text-sm leading-relaxed">{msg.content}</p>
                <span className={`text-xs opacity-70 mt-1 inline-block ${
                  msg.role === 'user' ? 'text-blue-100' : 'text-gray-600'
                }`}>
                  {new Date(msg.timestamp || Date.now()).toLocaleTimeString()}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll to bottom button */}
      {showScrollToBottom && (
        <button
          onClick={scrollToBottom}
          className="absolute bottom-4 right-4 bg-blue-500 hover:bg-blue-600 text-white rounded-full p-2 shadow-lg transition-all duration-300 animate-slideUp"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </button>
      )}

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn { animation: fadeIn 0.3s ease-out; }
        .animate-slideUp { animation: slideUp 0.3s ease-out; }
        .scroll-smooth { scroll-behavior: smooth; }
      `}</style>
    </div>
  );
}

// ============================================================================
// AI CHAT INTERFACE
// ============================================================================

export function AIChatInterface({ userId, userProfile }: any) {
  const { messages, isLoading, insights, sendMessage, getAdvice } = useAI();
  const [inputValue, setInputValue] = useState('');
  const [showInsights, setShowInsights] = useState(false);

  const handleSend = async () => {
    if (!inputValue.trim()) return;

    const userMessage = inputValue;
    setInputValue('');

    try {
      await sendMessage(userMessage);
      
      // Auto-generate advice if user asks about it
      if (userMessage.toLowerCase().includes('conseil') || userMessage.toLowerCase().includes('advice')) {
        await getAdvice(userProfile);
      }
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-4 sticky top-0 z-10">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold flex items-center gap-2">
              🤖 TransferAI
            </h2>
            <p className="text-xs text-blue-100">Votre assistant financier intelligent</p>
          </div>
          <button
            onClick={() => setShowInsights(!showInsights)}
            className="relative"
          >
            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
              💡
            </div>
            {insights.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {insights.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto">
        <CustomScrollableMessages
          messages={messages.map(msg => ({
            ...msg,
            timestamp: new Date()
          }))}
          isLoading={isLoading}
        />
      </div>

      {/* Insights Popup */}
      {showInsights && insights.length > 0 && (
        <div className="bg-gradient-to-r from-yellow-50 to-orange-50 border-t-2 border-yellow-200 p-4 max-h-48 overflow-y-auto">
          <h3 className="font-bold text-sm mb-3 text-gray-800">💡 Insights</h3>
          <div className="space-y-2">
            {insights.map(insight => (
              <div key={insight.id} className="bg-white rounded-lg p-2 text-sm">
                <div className="flex justify-between items-start gap-2">
                  <div className="flex-1">
                    <div className="font-bold text-gray-800">{insight.title}</div>
                    <div className="text-xs text-gray-600 mt-1">{insight.description}</div>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs font-bold whitespace-nowrap ${
                    insight.confidence > 80 ? 'bg-green-100 text-green-700' :
                    insight.confidence > 60 ? 'bg-yellow-100 text-yellow-700' :
                    'bg-gray-100 text-gray-700'
                  }`}>
                    {insight.confidence}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="bg-white border-t p-4 sticky bottom-0">
        <div className="flex gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Posez une question..."
            className="flex-1 border-2 border-gray-200 rounded-full px-4 py-2 focus:border-blue-500 outline-none transition"
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !inputValue.trim()}
            className="bg-blue-500 hover:bg-blue-600 disabled:bg-gray-300 text-white rounded-full px-4 py-2 transition"
          >
            {isLoading ? '⟳' : '→'}
          </button>
        </div>
        <div className="text-xs text-gray-600 mt-2">
          💡 Demandez des conseils, prédictions ou optimisations
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// ANALYTICS DASHBOARD WITH SMOOTH ANIMATIONS
// ============================================================================

export function AnalyticsDashboard({ userRevenue, transactions }: any) {
  const [selectedMetric, setSelectedMetric] = useState<'transfers' | 'revenue' | 'growth'>('transfers');
  const [animatedValues, setAnimatedValues] = useState({
    totalTransfers: 0,
    totalRevenue: 0,
    totalGrowth: 0
  });

  // Animate numbers
  useEffect(() => {
    const targets = {
      totalTransfers: transactions.length,
      totalRevenue: userRevenue?.totalMonthly || 0,
      totalGrowth: userRevenue?.totalMonthly ? 
        ((userRevenue.totalMonthly / (userRevenue.totalAllTime / 12)) * 100) : 0
    };

    let frame = 0;
    const interval = setInterval(() => {
      frame++;
      setAnimatedValues(prev => ({
        totalTransfers: Math.round(prev.totalTransfers + (targets.totalTransfers - prev.totalTransfers) * 0.05),
        totalRevenue: Math.round(prev.totalRevenue + (targets.totalRevenue - prev.totalRevenue) * 0.05),
        totalGrowth: Math.round(prev.totalGrowth + (targets.totalGrowth - prev.totalGrowth) * 0.05)
      }));

      if (frame > 20) clearInterval(interval);
    }, 30);

    return () => clearInterval(interval);
  }, [transactions.length, userRevenue]);

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-4 rounded-lg hover:shadow-lg transition-all duration-300 cursor-pointer"
          onClick={() => setSelectedMetric('transfers')}>
          <div className="text-3xl font-bold">{animatedValues.totalTransfers}</div>
          <div className="text-xs opacity-90">Transferts</div>
        </div>
        
        <div className="bg-gradient-to-br from-green-500 to-green-600 text-white p-4 rounded-lg hover:shadow-lg transition-all duration-300 cursor-pointer"
          onClick={() => setSelectedMetric('revenue')}>
          <div className="text-3xl font-bold">
            {new Intl.NumberFormat('fr-FR').format(Math.round(animatedValues.totalRevenue))}
          </div>
          <div className="text-xs opacity-90">Revenus/mois</div>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 text-white p-4 rounded-lg hover:shadow-lg transition-all duration-300 cursor-pointer"
          onClick={() => setSelectedMetric('growth')}>
          <div className="text-3xl font-bold">{Math.round(animatedValues.totalGrowth)}%</div>
          <div className="text-xs opacity-90">Croissance</div>
        </div>
      </div>

      {/* Revenue Breakdown */}
      <div className="bg-white rounded-lg p-4 shadow">
        <h3 className="font-bold mb-4">Breakdown des revenus</h3>
        <div className="space-y-3">
          {[
            { label: 'Référrals', value: userRevenue?.referralEarnings || 0, color: 'bg-blue-500' },
            { label: 'Commissions Agent', value: userRevenue?.agentCommissions || 0, color: 'bg-green-500' },
            { label: 'Intérêts', value: userRevenue?.interestEarned || 0, color: 'bg-orange-500' },
            { label: 'Affilié', value: userRevenue?.affiliateEarnings || 0, color: 'bg-purple-500' },
            { label: 'Créateur', value: userRevenue?.creatorRewards || 0, color: 'bg-pink-500' },
          ].map((item) => {
            const total = (userRevenue?.referralEarnings || 0) + 
                         (userRevenue?.agentCommissions || 0) +
                         (userRevenue?.interestEarned || 0) +
                         (userRevenue?.affiliateEarnings || 0) +
                         (userRevenue?.creatorRewards || 0);
            const percentage = total > 0 ? (item.value / total) * 100 : 0;

            return (
              <div key={item.label}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">{item.label}</span>
                  <span className="text-gray-600">
                    {new Intl.NumberFormat('fr-FR').format(item.value)} XAF
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                  <div
                    className={`${item.color} h-full rounded-full transition-all duration-500`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="bg-white rounded-lg p-4 shadow">
        <h3 className="font-bold mb-4">Transactions récentes</h3>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {transactions.slice(0, 10).map((txn: any, idx: number) => (
            <div key={idx} className="flex justify-between items-center p-2 hover:bg-gray-50 rounded transition">
              <div className="text-sm">
                <div className="font-medium">{txn.type}</div>
                <div className="text-xs text-gray-600">{new Date(txn.createdAt).toLocaleDateString('fr-FR')}</div>
              </div>
              <div className={`font-bold ${txn.status === 'completed' ? 'text-green-600' : 'text-yellow-600'}`}>
                {txn.status === 'completed' ? '+' : '⏳'} {new Intl.NumberFormat('fr-FR').format(txn.amount)}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// ANIMATED PROGRESS INDICATOR
// ============================================================================

export function AnimatedProgressRing({
  percentage,
  radius = 45,
  stroke = 4,
  label
}: {
  percentage: number;
  radius?: number;
  stroke?: number;
  label?: string;
}) {
  const normalizedRadius = radius - stroke / 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const offset = circumference - (percentage / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center">
      <svg width={radius * 2} height={radius * 2} className="transform -rotate-90">
        <circle
          stroke="#e5e7eb"
          fill="transparent"
          strokeWidth={stroke}
          r={normalizedRadius}
          cx={radius}
          cy={radius}
        />
        <circle
          stroke="#3b82f6"
          fill="transparent"
          strokeWidth={stroke}
          strokeDasharray={circumference + ' ' + circumference}
          strokeDashoffset={offset}
          r={normalizedRadius}
          cx={radius}
          cy={radius}
          className="transition-all duration-500"
          strokeLinecap="round"
        />
      </svg>
      <div className="absolute text-center">
        <div className="text-2xl font-bold text-blue-600">{Math.round(percentage)}%</div>
        {label && <div className="text-xs text-gray-600">{label}</div>}
      </div>
    </div>
  );
}

// ============================================================================
// GESTURE-BASED SWIPE DETECTION
// ============================================================================

export function useSwipe(handler: (direction: 'left' | 'right' | 'up' | 'down') => void, threshold = 50) {
  const touchStartRef = useRef({ x: 0, y: 0 });

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartRef.current = {
      x: e.touches[0].clientX,
      y: e.touches[0].clientY
    };
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    const touchEnd = {
      x: e.changedTouches[0].clientX,
      y: e.changedTouches[0].clientY
    };

    const diffX = touchStartRef.current.x - touchEnd.x;
    const diffY = touchStartRef.current.y - touchEnd.y;

    if (Math.abs(diffX) > Math.abs(diffY)) {
      if (diffX > threshold) handler('left');
      else if (diffX < -threshold) handler('right');
    } else {
      if (diffY > threshold) handler('up');
      else if (diffY < -threshold) handler('down');
    }
  };

  return { handleTouchStart, handleTouchEnd };
}
